<?php
###############################################
//To genrate n numbers of record use this follow steps//
// Step 1:  got terminal of where file located //
// for exxample 
 // /var/www/html/mindtree2$
 // run this command "php -f genraten.php"



########################################
$servername = "localhost";
$username = "manesh";
$password = "manesh";

try {
  $conn = new PDO("mysql:host=$servername;dbname=coding_test", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $n=10;
  $iplists = genIps($n);
  $maclists = genMac($n);
  for($i=0;$i<$n;$i++){
        $sql = "INSERT INTO routers (sap_id, hostname, loopback,mac_address)
      VALUES ('sapid123333', '".$iplists[$i]."', '".$iplists[$i]."','".$maclists[$i]."')";
      // use exec() because no results are returned
      $conn->exec($sql);
  }
  echo "New record created successfully";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}

  function genIps($counter=10) {
      $arr =array();
    $n1 = 0;
    $n2 = 0;
    $n3 = 0;
    $n4 = 0;

    while ($n4 <= 255 && $n3 <= 255) {
        if($counter ==0){
            break;
        }
        $arr[] = $n1++.'.'.$n2++.'.'.$n3++.'.'.$n4++;
        --$counter;
    }
    return $arr;
}


 function genMac($counter=10) {
      $arr =array();
       $mac = "AA:BB:CC:DD:";
    $n1 = 0;
    $n2 = 0;
    while ($n1 <= 255 && $n2 <= 255) {
        if($counter ==0){
            break;
        }
        $arr[] = $mac. $n1++.$n2++;
        --$counter;
    }
    return $arr;
}
?>