<?php
$dir    = '/tmp';
$files1 = scandir($dir);
$files2 = scandir($dir, 1); //descending order in

print_r($files1);
print_r($files2);
?>
