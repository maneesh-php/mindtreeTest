<?php

// USING FTP //
$local_file = 'localname.zip'; // the nam
$server_file = 'servername.zip';
$conn = ftp_connect($ftp_server);

$login_result = ftp_login($conn, $ftp_user_name, $ftp_user_pass);

if (ftp_get($conn, $local_file, $server_file, FTP_BINARY)) {
    echo "Successfully copied";
}
ftp_close($conn);


// USING SFTP //


$src = 'Some_file_location';

$filename = 'new_file.txt';
$dest = '/destination_directory/'.$filename;

// set up sftp ssh-sftp connection
$connection = ssh2_connect('ftp.otherdomain.com', 22);
ssh2_auth_password($connection, 'username', 'password');

// Create SFTP session
$sftp = ssh2_sftp($connection);

$sftpStream = @fopen('ssh2.sftp://'.$sftp.$dest, 'w');

try {
		
	if (!$sftpStream) {
	throw new Exception("Could not open remote file: $dest");
	}

	$data_to_send = @file_get_contents($src);

	if ($data_to_send === false) {
	throw new Exception("Could not open local file: $src.");
	}

	if (@fwrite($sftpStream, $data_to_send) === false) {
	throw new Exception("Could not send data from file: $src.");
	} else {

	//Upload was successful, post-upload actions go here...

	}

	fclose($sftpStream);
			   
	} catch (Exception $e) {

	error_log('Exception: ' . $e->getMessage());

	fclose($sftpStream);
	}




?>
