<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title> Assignment Test</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
	<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>

<div id="container">
	<h1>Router's List! <a style="float:right;" href="<?php echo base_url('welcome/add');?>">Add New Router</a></h1>

	<div id="body">
<table id="customers">
  <tr>
    <th>Sap Id</th>
    <th>Hostname</th>
    <th>Loopback (IPv4)</th>
	<th>Mac Address</th>
	<th>Action</th>
  </tr>
  <?php if(isset($list)){ ?>
	<?php foreach($list as $val){ ?>
  <tr>
    <td><?php echo $val->sap_id ;?></td>
    <td><?php echo $val->hostname ;?></td>
    <td><?php echo $val->loopback ;?></td>
	<td><?php echo $val->mac_address ;?></td>
	<td><a href="<?php echo base_url('welcome/edit/'.$val->id);?>">Edit </a> &nbsp;&nbsp;<a href="javascript:void(0);" onclick="deleteMe('<?php echo $val->id;?>')" >Delete </a></td>
  </tr>
	<?php }?>
  <?php }else{ ?>
	<tr>
    <td colspan="7">No routers available.</td>
  </tr>
  <?php }?>
</table>

	</div>

	<p class="footer">Developed By: Maneesh Kumar</p>
</div>
<script>
function deleteMe(id){
  if(confirm("Are you sure want to delete this record?.")){
	$.ajax({
					type: "POST",
					url: "<?php echo base_url('welcome/deleteRouter');?>",
					data: {id:id},
					success: function(data, textStatus, jqXHR)
					{
						if(data == 'Deleted'){
							alert(data);
							window.location.href="";
						}else{
							alert(data);
						}
					
					},
					error: function (jqXHR, textStatus, errorThrown)
					{
							alert("Something went wrong!"); 
					}
			});
			return false;
  }
  return false;
}
</script>
</body>
</html>