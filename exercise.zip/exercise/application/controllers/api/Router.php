<?php

require APPPATH.'libraries/REST_Controller.php';

class Router extends REST_Controller{

  public function __construct(){

    parent::__construct();
    //load database
    $this->load->database();
    $this->load->model(array("api/router_model"));
    $this->load->library(array("form_validation"));
    $this->load->helper("security");
  }

  /*
    INSERT: POST REQUEST TYPE
    UPDATE: PUT REQUEST TYPE
    DELETE: DELETE REQUEST TYPE
    LIST: Get REQUEST TYPE
  */
 
  // POST: <project_url>/index.php/Router
  public function index_post(){
    // insert data method
    $data = json_decode(file_get_contents("php://input"),true);
    if(empty($data)){
      $data  = $this->input->post();
    }

    // collecting form data inputs
    $sapid = $this->security->xss_clean($data["sapid"]);
    $hostname = $this->security->xss_clean($data["hostname"]);
    $loopback = $this->security->xss_clean($data["loopback"]);
    $mac_add = $this->security->xss_clean($data["mac_add"]);
      if(!empty($sapid) && !empty($loopback) && !empty($hostname) && !empty($mac_add) ){
      
        if(false === $this->validateHostName($hostname)){
          $this->response(array(
            "status" => 0,
            "message" => "Hostname is not valid."
          ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
					
        }
				if(!$this->validateIPV4($loopback)){
          $this->response(array(
            "status" => 0,
            "message" => "loopabck(IPV4) is not valid."
          ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
			
				}

				if(!$this->validateMac($mac_add)){
          $this->response(array(
            "status" => 0,
            "message" => "Mac address is not valid."
          ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
				
				}
        // all values are available
        $Router =array(
					'sap_id' => $sapid,
					'loopback' => $loopback,
					'hostname' => $hostname,
					'mac_address' => $mac_add,
				);

        if($this->router_model->insert_Router($Router)){

          $this->response(array(
            "status" => 1,
            "message" => "Router has been created"
          ), REST_Controller::HTTP_OK);
        }else{

          $this->response(array(
            "status" => 0,
            "message" => "Failed to create Router"
          ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
        }
      }else{
        // we have some empty field
        $this->response(array(
          "status" => 0,
          "message" => "All fields are needed"
        ), REST_Controller::HTTP_NOT_FOUND);
      }
    

    /*$data = json_decode(file_get_contents("php://input"));

    $name = isset($data->name) ? $data->name : "";
    $email = isset($data->email) ? $data->email : "";
    $mobile = isset($data->mobile) ? $data->mobile : "";
    $course = isset($data->course) ? $data->course : "";*/


  }

  // PUT: <project_url>/index.php/Router
  public function index_put(){
    // updating data method
    //echo "This is PUT Method";
    $data = json_decode(file_get_contents("php://input"));
    // collecting form data inputs
    $sapid = $this->security->xss_clean($data->sapid);
    $hostname = $this->security->xss_clean($data->hostname);
    $loopback = $this->security->xss_clean($data->loopback);
    $mac_add = $this->security->xss_clean($data->mac_add);
    $Router_id = $this->security->xss_clean($data->id);


    if(!empty($sapid) && !empty($loopback) && !empty($hostname) && !empty($mac_add) ){

      $Router_info = array(
        'sap_id' => $sapid,
        'loopback' => $loopback,
        'hostname' => $hostname,
        'mac_address' => $mac_add,
      );


      if(!$this->validateHostName($hostname)){
        $this->response(array(
          "status" => 0,
          "message" => "Hostname is not valid."
        ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
        
      }
      if(!$this->validateIPV4($loopback)){
        $this->response(array(
          "status" => 0,
          "message" => "loopabck(IPV4) is not valid."
        ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
    
      }

      if(!$this->validateMac($mac_add)){
        $this->response(array(
          "status" => 0,
          "message" => "Mac address is not valid."
        ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
      
      }

      if($this->router_model->update_router($Router_info,$Router_id)){

          $this->response(array(
            "status" => 1,
            "message" => "Router data updated successfully"
          ), REST_Controller::HTTP_OK);
      }else{

        $this->response(array(
          "status" => 0,
          "messsage" => "Failed to update Router data"
        ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
      }
    }else{

      $this->response(array(
        "status" => 0,
        "message" => "All fields are needed"
      ), REST_Controller::HTTP_NOT_FOUND);
    }
  }

  // DELETE: <project_url>/index.php/Router
  public function index_delete(){
    // delete data method
    $data = json_decode(file_get_contents("php://input"));
    $Router_id = $this->security->xss_clean($data->Router_id);

    if($this->router_model->delete_router($Router_id)){
      // retruns true
      $this->response(array(
        "status" => 1,
        "message" => "Router has been deleted"
      ), REST_Controller::HTTP_OK);
    }else{
      // return false
      $this->response(array(
        "status" => 0,
        "message" => "Failed to delete Router"
      ), REST_Controller::HTTP_NOT_FOUND);
    }
  }

  // GET: <project_url>/index.php/Router
  public function index_get(){
    // list data method
    //echo "This is GET Method";
    // SELECT * from tbl_Routers;
    $Routers = $this->router_model->get_routers();

    //print_r($query->result());

    if(count($Routers) > 0){

      $this->response(array(
        "status" => 1,
        "message" => "Routers found",
        "data" => $Routers
      ), REST_Controller::HTTP_OK);
    }else{

      $this->response(array(
        "status" => 0,
        "message" => "No Routers found",
        "data" => $Routers
      ), REST_Controller::HTTP_NOT_FOUND);
    }



  }

  function validateHostName($ip) {
		return filter_var($ip, FILTER_VALIDATE_IP); 
	}

	function validateIPV4($ip) {
		return filter_var($ip, FILTER_VALIDATE_IP,FILTER_FLAG_IPV4);
	}

	function validateMac($mac) {
		return filter_var($mac, FILTER_VALIDATE_MAC);
	}
}

 ?>
