<?php

class Router_model extends CI_Model{

  public function __construct(){
    parent::__construct();
    $this->load->database();
  }

  public function get_routers(){

    $this->db->select("*");
    $this->db->from("routers");
    $this->db->where('status',1);
    $query = $this->db->get();
    return $query->result();
  }

  public function get_routers_details($id=null){
    if(!empty($id)){
      $this->db->select("*");
      $this->db->from("routers");
      $this->db->where('id',$id);
      $query = $this->db->get();
      return $query->row();
    }
    return false;
  }

   public function insert_student($data = array()){

       return $this->db->insert("routers", $data);
   }

   public function insert_router($data = array()){

    return $this->db->insert("routers", $data);
  }

  public function update_router($data = array(),$id){
      $this->db->where('id',$id);
    return $this->db->update("routers", $data);
  }

   

   public function delete_router($id){
     $this->db->where("id", $id);
     return $this->db->update("routers" ,array('status'=>0));
   }

   public function update_student_information($id, $informations){

      $this->db->where("id", $id);
      return $this->db->update("routers", $informations);
   }
}

 ?>
