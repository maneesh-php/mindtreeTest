<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct(){

		parent::__construct();
		//load database
		$this->load->database();
		$this->load->model(array("api/router_model"));
		$this->load->library(array("form_validation"));
		$this->load->helper("security");
	  }
	public function index()
	{
		$data['list'] = $this->router_model->get_routers();
		$this->load->view('routers_list',$data);
	}

	public function add()
	{
		$this->load->view('add');
	}
	public function edit($id)
	{
		$data['detail'] = $this->router_model->get_routers_details($id);
		$this->load->view('edit',$data);
	}
	public function addRouter()
	{
		if($_POST){
			if(!empty($_POST['sapid']) && !empty($_POST['hostname']) && !empty($_POST['loopback']) && !empty($_POST['mac_add']) ){
				$sapid = $this->security->xss_clean($this->input->post("sapid"));
				$hostname = $this->security->xss_clean($this->input->post("hostname"));
				$loopback = $this->security->xss_clean($this->input->post("loopback"));
				$mac_add = $this->security->xss_clean($this->input->post("mac_add"));
				if(!$this->validateHostName($hostname)){
					echo "Hostname is not valid." ; die;
				}
				if(!$this->validateIPV4($loopback)){
					echo "loopabck(IPV4) is not valid." ; die;
				}

				if(!$this->validateMac($mac_add)){
					echo "Mac address is not valid." ; die;
				}
				
				$data =array(
					'sap_id' => $sapid,
					'loopback' => $loopback,
					'hostname' => $hostname,
					'mac_address' => $mac_add,
				);
				if($this->router_model->insert_router($data)){
					echo "New router addedd!!" ; die;
				}
				echo "Some error occured while adding router" ; die;
			}else{
				echo "All mandatory field required!!" ; die;
			}
		}
		echo "Invalid request!!" ; die;
	}

	public function updateRouter()
	{
		if($_POST){
			if(!empty($_POST['sapid']) && !empty($_POST['hostname']) && !empty($_POST['loopback']) && !empty($_POST['mac_add']) && !empty($_POST['id']) ){
				$sapid = $this->security->xss_clean($this->input->post("sapid"));
				$hostname = $this->security->xss_clean($this->input->post("hostname"));
				$loopback = $this->security->xss_clean($this->input->post("loopback"));
				$mac_add = $this->security->xss_clean($this->input->post("mac_add"));
				$id = $this->security->xss_clean($this->input->post("id"));

				if(!$this->validateHostName($hostname)){
					echo "Hostname is not valid." ; die;
				}
				if(!$this->validateIPV4($loopback)){
					echo "loopabck(IPV4) is not valid." ; die;
				}

				if(!$this->validateMac($mac_add)){
					echo "Mac address is not valid." ; die;
				}
				$data =array(
					'sap_id' => $sapid,
					'loopback' => $loopback,
					'hostname' => $hostname,
					'mac_address' => $mac_add,
				);
				if($this->router_model->update_router($data,$id)){
					echo "Router updated!!" ; die;
				}
				echo "Some error occured while updating router" ; die;
			}else{
				echo "All mandatory field required!!" ; die;
			}
		}
		echo "Invalid request!!" ; die;
	}


	public function deleteRouter()
	{
		if($_POST['id']){
				if($this->router_model->delete_router($_POST['id'])){
					echo "Deleted"; die;
				}else{
					echo "Error"; die;
				}
		}
		echo "Invalid Request!!"; die;
	}

	function validateHostName($ip) {
		return filter_var($ip, FILTER_VALIDATE_IP);
	}

	function validateIPV4($ip) {
		return filter_var($ip, FILTER_VALIDATE_IP,FILTER_FLAG_IPV4);
	}

	function validateMac($mac) {
		return filter_var($mac, FILTER_VALIDATE_MAC);
	}

	public function testapi(){
		$res='';
		if($_POST){
			$res['data']=$this->CallAPI($_POST['methoName'],$_POST['url'],$_POST);
		}
		$this->load->view('testapi',$res);
	}

	function CallAPI($method, $url, $data = false)
		{
			$curl = curl_init();

			switch ($method)
			{
				case "POST":
					curl_setopt($curl, CURLOPT_POST, 1);

					if ($data)
						curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
					break;
				case "PUT":
					curl_setopt($curl, CURLOPT_PUT, 1);
					break;
				default:
					if ($data)
						$url = sprintf("%s?%s", $url, http_build_query($data));
			}

			// Optional Authentication:
			curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			curl_setopt($curl, CURLOPT_USERPWD, "username:password");

			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

			$result = curl_exec($curl);

			curl_close($curl);

			return $result;
		}
	
}
